package com.example.a3_monthhomework7

data class Animal(
    var name: String? = null,
    var image: Int? = null
)
